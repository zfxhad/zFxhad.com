#requires -version 5.1
<#
.SYNOPSIS
    Fahad PC Tweaks V1 - interactive, reversible Windows tweak manager.
.DESCRIPTION
    Detects the PC, creates a restore point before changes, shows each tweak's
    current state and risk level, lets the user apply/restore/skip tweaks one by
    one, keeps a backup of original values, logs results, and requests a restart
    only when a selected tweak requires one.
.AUTHOR
    Fahad
#>

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ToolName    = 'Fahad PC Tweaks'
$ToolVersion = '1.0'
$DataDir     = Join-Path $env:ProgramData 'FahadPCTweaks'
$BackupFile  = Join-Path $DataDir 'OriginalSettings.json'
$LogFile     = Join-Path $DataDir 'Activity.log'
$script:RestartRequired = $false
$script:Results = New-Object System.Collections.ArrayList

# ------------------------------
# Helpers
# ------------------------------
function Write-Title {
    Clear-Host
    Write-Host ('=' * 68) -ForegroundColor DarkGray
    Write-Host ("{0}  v{1}" -f $ToolName, $ToolVersion) -ForegroundColor Cyan
    Write-Host ('=' * 68) -ForegroundColor DarkGray
}

function Write-Section([string]$Text) {
    Write-Host ''
    Write-Host $Text -ForegroundColor Yellow
    Write-Host ('-' * 68) -ForegroundColor DarkGray
}

function Ensure-DataDirectory {
    if (-not (Test-Path $DataDir)) {
        New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
    }
}

function Write-Log([string]$Message) {
    Ensure-DataDirectory
    $stamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    Add-Content -Path $LogFile -Value "[$stamp] $Message" -Encoding UTF8
}

function Add-Result([string]$Name, [ValidateSet('PASS','FAIL','SKIP','INFO')][string]$Status, [string]$Message) {
    [void]$script:Results.Add([pscustomobject]@{
        Tweak = $Name
        Status = $Status
        Message = $Message
    })
    Write-Log "$Status | $Name | $Message"
}

function Test-Administrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Ensure-Administrator {
    if (Test-Administrator) { return }

    Write-Host 'Administrator privileges are required. Opening a UAC prompt...' -ForegroundColor Yellow
    try {
        $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f $PSCommandPath))
        Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $argList
    } catch {
        Write-Host "Could not elevate: $($_.Exception.Message)" -ForegroundColor Red
        Read-Host 'Press Enter to exit'
    }
    exit
}

function Get-BackupData {
    Ensure-DataDirectory
    if (-not (Test-Path $BackupFile)) {
        return @{ Version = $ToolVersion; Created = (Get-Date).ToString('o'); Tweaks = @{} }
    }
    try {
        $raw = Get-Content -Raw -Path $BackupFile -Encoding UTF8
        $obj = $raw | ConvertFrom-Json
        $hash = @{ Version = $obj.Version; Created = $obj.Created; Tweaks = @{} }
        if ($obj.Tweaks) {
            foreach ($p in $obj.Tweaks.PSObject.Properties) {
                $hash.Tweaks[$p.Name] = $p.Value
            }
        }
        return $hash
    } catch {
        Write-Log "WARN | Backup file could not be parsed: $($_.Exception.Message)"
        return @{ Version = $ToolVersion; Created = (Get-Date).ToString('o'); Tweaks = @{} }
    }
}

function Save-BackupData($Data) {
    Ensure-DataDirectory
    $Data | ConvertTo-Json -Depth 12 | Set-Content -Path $BackupFile -Encoding UTF8
}

function Save-OriginalOnce([string]$Id, $OriginalData) {
    $data = Get-BackupData
    if (-not $data.Tweaks.ContainsKey($Id)) {
        $data.Tweaks[$Id] = $OriginalData
        Save-BackupData $data
        Write-Log "BACKUP | $Id | Original state saved"
    }
}

function Get-SavedOriginal([string]$Id) {
    $data = Get-BackupData
    if ($data.Tweaks.ContainsKey($Id)) { return $data.Tweaks[$Id] }
    return $null
}

function Get-RegValueInfo([string]$Path, [string]$Name) {
    if (-not (Test-Path $Path)) {
        return [pscustomobject]@{ PathExists=$false; ValueExists=$false; Value=$null; Kind=$null }
    }
    try {
        $key = Get-Item -Path $Path
        $names = @($key.GetValueNames())
        if ($names -contains $Name) {
            return [pscustomobject]@{
                PathExists=$true
                ValueExists=$true
                Value=$key.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
                Kind=$key.GetValueKind($Name).ToString()
            }
        }
    } catch {}
    return [pscustomobject]@{ PathExists=$true; ValueExists=$false; Value=$null; Kind=$null }
}

function Set-RegDword([string]$Path, [string]$Name, [int]$Value) {
    if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
    New-ItemProperty -Path $Path -Name $Name -PropertyType DWord -Value $Value -Force | Out-Null
}

function Restore-RegValue([string]$Path, [string]$Name, $Saved) {
    if ($null -eq $Saved) { return $false }
    if ([bool]$Saved.ValueExists) {
        if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
        $kind = if ($Saved.Kind) { [string]$Saved.Kind } else { 'DWord' }
        New-ItemProperty -Path $Path -Name $Name -PropertyType $kind -Value $Saved.Value -Force | Out-Null
    } else {
        if (Test-Path $Path) {
            Remove-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
        }
    }
    return $true
}

function Format-State([string]$State) {
    switch ($State) {
        'ACTIVE'   { return '[ON]' }
        'INACTIVE' { return '[OFF]' }
        'DEFAULT'  { return '[DEFAULT]' }
        'N/A'      { return '[N/A]' }
        'MIXED'    { return '[MIXED]' }
        default    { return "[$State]" }
    }
}

function Get-SystemInfo {
    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $gpus = @(Get-CimInstance Win32_VideoController | Where-Object { $_.Name })
    $ramGB = [math]::Round(($os.TotalVisibleMemorySize * 1KB) / 1GB, 0)
    $adapters = @(Get-CimInstance Win32_NetworkAdapter | Where-Object { $_.PhysicalAdapter -and $_.MACAddress })

    return [pscustomobject]@{
        Windows = $os.Caption
        Version = $os.Version
        Build = $os.BuildNumber
        CPU = $cpu.Name
        RAMGB = [int]$ramGB
        GPUs = $gpus
        HasNvidia = [bool]($gpus | Where-Object { $_.Name -match 'NVIDIA' })
        HasAMD = [bool]($gpus | Where-Object { $_.Name -match 'AMD|Radeon' })
        NetworkAdapters = $adapters
    }
}

function Show-SystemInfo($Sys) {
    Write-Section 'SYSTEM DETECTION'
    Write-Host ("Windows : {0} ({1}, Build {2})" -f $Sys.Windows, $Sys.Version, $Sys.Build)
    Write-Host ("CPU     : {0}" -f $Sys.CPU)
    Write-Host ("RAM     : {0} GB" -f $Sys.RAMGB)
    $gpuNames = @($Sys.GPUs | ForEach-Object { $_.Name }) -join ' | '
    Write-Host ("GPU     : {0}" -f $(if ($gpuNames) {$gpuNames} else {'Unknown'}))
    $netNames = @($Sys.NetworkAdapters | Select-Object -ExpandProperty Name) -join ' | '
    Write-Host ("Network : {0}" -f $(if ($netNames) {$netNames} else {'No physical adapter detected'}))
}

# ------------------------------
# Core feature 1: Restore point
# ------------------------------
function Create-SafetyRestorePoint {
    Write-Section '1. CREATE RESTORE POINT'
    try {
        Checkpoint-Computer -Description 'Fahad PC Tweaks - Before Changes' -RestorePointType MODIFY_SETTINGS
        Write-Host '[PASS] Restore point created.' -ForegroundColor Green
        Add-Result 'Create Restore Point' 'PASS' 'Restore point created before changes.'
        return $true
    } catch {
        Write-Host '[WARN] Windows could not create a new restore point.' -ForegroundColor Yellow
        Write-Host ('Reason: {0}' -f $_.Exception.Message) -ForegroundColor DarkYellow
        Write-Host 'Windows may limit restore-point creation (for example, another one may already exist recently).' -ForegroundColor DarkYellow
        Add-Result 'Create Restore Point' 'FAIL' $_.Exception.Message
        $answer = (Read-Host 'Continue anyway? [Y/N]').Trim().ToUpperInvariant()
        return ($answer -eq 'Y')
    }
}

# ------------------------------
# Tweak 3: MPO
# ------------------------------
$MpoPath = 'HKLM:\SOFTWARE\Microsoft\Windows\Dwm'
function Get-MPOState {
    $v = Get-RegValueInfo $MpoPath 'OverlayTestMode'
    if ($v.ValueExists -and [int]$v.Value -eq 5) { return 'ACTIVE' }
    if (-not $v.ValueExists) { return 'DEFAULT' }
    return 'INACTIVE'
}
function Enable-MPOTweak {
    $orig = Get-RegValueInfo $MpoPath 'OverlayTestMode'
    Save-OriginalOnce 'MPO' $orig
    Set-RegDword $MpoPath 'OverlayTestMode' 5
    $script:RestartRequired = $true
    return ((Get-MPOState) -eq 'ACTIVE')
}
function Restore-MPOTweak {
    $saved = Get-SavedOriginal 'MPO'
    if ($null -eq $saved) { return $false }
    $ok = Restore-RegValue $MpoPath 'OverlayTestMode' $saved
    $script:RestartRequired = $true
    return $ok
}

# ------------------------------
# Tweak 4: NetBIOS over TCP/IP
# ------------------------------
function Get-NetBiosAdapters {
    return @(Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled })
}
function Get-NetBIOSState {
    $items = @(Get-NetBiosAdapters)
    if ($items.Count -eq 0) { return 'N/A' }
    # TcpipNetbiosOptions: 0=DHCP/default, 1=enabled, 2=disabled
    $states = @($items | ForEach-Object { [int]$_.TcpipNetbiosOptions })
    if (($states | Where-Object { $_ -ne 2 }).Count -eq 0) { return 'ACTIVE' }
    if (($states | Where-Object { $_ -eq 2 }).Count -eq 0) { return 'INACTIVE' }
    return 'MIXED'
}
function Enable-NetBIOSTweak {
    $items = @(Get-NetBiosAdapters)
    $orig = @($items | ForEach-Object { [pscustomobject]@{ Index=$_.Index; SettingID=$_.SettingID; TcpipNetbiosOptions=[int]$_.TcpipNetbiosOptions } })
    Save-OriginalOnce 'NetBIOS' ([pscustomobject]@{ Adapters=$orig })
    foreach ($a in $items) {
        $r = Invoke-CimMethod -InputObject $a -MethodName SetTcpipNetbios -Arguments @{ TcpipNetbiosOptions = [uint32]2 }
        if ($r.ReturnValue -notin 0,1) { throw "NetBIOS change failed on adapter $($a.Description), code $($r.ReturnValue)" }
    }
    return ((Get-NetBIOSState) -eq 'ACTIVE')
}
function Restore-NetBIOSTweak {
    $saved = Get-SavedOriginal 'NetBIOS'
    if ($null -eq $saved -or -not $saved.Adapters) { return $false }
    foreach ($entry in @($saved.Adapters)) {
        $a = Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.SettingID -eq [string]$entry.SettingID } | Select-Object -First 1
        if ($a) {
            $r = Invoke-CimMethod -InputObject $a -MethodName SetTcpipNetbios -Arguments @{ TcpipNetbiosOptions = [uint32][int]$entry.TcpipNetbiosOptions }
            if ($r.ReturnValue -notin 0,1) { throw "NetBIOS restore failed on adapter $($a.Description), code $($r.ReturnValue)" }
        }
    }
    return $true
}

# ------------------------------
# Tweak 5: Network Heuristics
# ------------------------------
function Get-NetworkHeuristicsState {
    try {
        $out = (& netsh int tcp show heuristics 2>&1 | Out-String)
        if ($out -match '(?im)force.*window.*scal.*:\s*(disabled|off)' -or $out -match '(?im)Window Scaling heuristics.*disabled') { return 'ACTIVE' }
        if ($out -match '(?im)enabled|default') { return 'INACTIVE' }
    } catch {}
    return 'UNKNOWN'
}
function Enable-NetworkHeuristicsTweak {
    $before = (& netsh int tcp show heuristics 2>&1 | Out-String)
    Save-OriginalOnce 'NetworkHeuristics' ([pscustomobject]@{ Raw=$before })
    $out = (& netsh int tcp set heuristics disabled 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) { throw $out }
    return $true
}
function Restore-NetworkHeuristicsTweak {
    # Microsoft exposes "default" for restoration.
    $out = (& netsh int tcp set heuristics default 2>&1 | Out-String)
    if ($LASTEXITCODE -ne 0) { throw $out }
    return $true
}

# ------------------------------
# Tweak 6: Kernel Debug Poll Interval
# ------------------------------
$KernelPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Kernel'
function Get-KernelDebugPollState {
    $v = Get-RegValueInfo $KernelPath 'DebugPollInterval'
    if ($v.ValueExists -and [int]$v.Value -eq 1000) { return 'ACTIVE' }
    if (-not $v.ValueExists) { return 'DEFAULT' }
    return 'INACTIVE'
}
function Enable-KernelDebugPollTweak {
    $orig = Get-RegValueInfo $KernelPath 'DebugPollInterval'
    Save-OriginalOnce 'KernelDebugPollInterval' $orig
    Set-RegDword $KernelPath 'DebugPollInterval' 1000
    $script:RestartRequired = $true
    return ((Get-KernelDebugPollState) -eq 'ACTIVE')
}
function Restore-KernelDebugPollTweak {
    $saved = Get-SavedOriginal 'KernelDebugPollInterval'
    if ($null -eq $saved) { return $false }
    $ok = Restore-RegValue $KernelPath 'DebugPollInterval' $saved
    $script:RestartRequired = $true
    return $ok
}

# ------------------------------
# Tweak 7: Disable NCSI Active Probing
# ------------------------------
$NcsiPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\NlaSvc\Parameters\Internet'
function Get-ActiveProbingState {
    $v = Get-RegValueInfo $NcsiPath 'EnableActiveProbing'
    if ($v.ValueExists -and [int]$v.Value -eq 0) { return 'ACTIVE' }
    if (-not $v.ValueExists -or [int]$v.Value -eq 1) { return 'INACTIVE' }
    return 'INACTIVE'
}
function Enable-ActiveProbingTweak {
    $orig = Get-RegValueInfo $NcsiPath 'EnableActiveProbing'
    Save-OriginalOnce 'DisableActiveProbing' $orig
    Set-RegDword $NcsiPath 'EnableActiveProbing' 0
    return ((Get-ActiveProbingState) -eq 'ACTIVE')
}
function Restore-ActiveProbingTweak {
    $saved = Get-SavedOriginal 'DisableActiveProbing'
    if ($null -eq $saved) { return $false }
    return (Restore-RegValue $NcsiPath 'EnableActiveProbing' $saved)
}

# ------------------------------
# Tweak 8: Disable GPU Preemption
# User-supplied experimental registry value.
# ------------------------------
$GpuSchedulerPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\Scheduler'
function Get-GPUPreemptionState {
    $v = Get-RegValueInfo $GpuSchedulerPath 'DisablePreemption'
    if ($v.ValueExists -and [int]$v.Value -eq 1) { return 'ACTIVE' }
    if (-not $v.ValueExists) { return 'DEFAULT' }
    return 'INACTIVE'
}
function Enable-GPUPreemptionTweak {
    $orig = Get-RegValueInfo $GpuSchedulerPath 'DisablePreemption'
    Save-OriginalOnce 'DisableGPUPreemption' $orig
    Set-RegDword $GpuSchedulerPath 'DisablePreemption' 1
    $script:RestartRequired = $true
    return ((Get-GPUPreemptionState) -eq 'ACTIVE')
}
function Restore-GPUPreemptionTweak {
    $saved = Get-SavedOriginal 'DisableGPUPreemption'
    if ($null -eq $saved) { return $false }
    $ok = Restore-RegValue $GpuSchedulerPath 'DisablePreemption' $saved
    $script:RestartRequired = $true
    return $ok
}

# ------------------------------
# Tweak 9: Disable automatic driver searching
# Keeps the user's requested SearchOrderConfig and also uses the current policy key.
# ------------------------------
$DriverSearchPath = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching'
$DriverPolicyPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DriverSearching'
function Get-DriverSearchState {
    $a = Get-RegValueInfo $DriverSearchPath 'SearchOrderConfig'
    $b = Get-RegValueInfo $DriverPolicyPath 'DontSearchWindowsUpdate'
    if ($a.ValueExists -and [int]$a.Value -eq 0 -and $b.ValueExists -and [int]$b.Value -eq 1) { return 'ACTIVE' }
    if ((-not $a.ValueExists -or [int]$a.Value -ne 0) -and (-not $b.ValueExists -or [int]$b.Value -ne 1)) { return 'INACTIVE' }
    return 'MIXED'
}
function Enable-DriverSearchTweak {
    Save-OriginalOnce 'DriverSearching' ([pscustomobject]@{
        SearchOrderConfig = Get-RegValueInfo $DriverSearchPath 'SearchOrderConfig'
        DontSearchWindowsUpdate = Get-RegValueInfo $DriverPolicyPath 'DontSearchWindowsUpdate'
    })
    Set-RegDword $DriverSearchPath 'SearchOrderConfig' 0
    Set-RegDword $DriverPolicyPath 'DontSearchWindowsUpdate' 1
    return ((Get-DriverSearchState) -eq 'ACTIVE')
}
function Restore-DriverSearchTweak {
    $saved = Get-SavedOriginal 'DriverSearching'
    if ($null -eq $saved) { return $false }
    [void](Restore-RegValue $DriverSearchPath 'SearchOrderConfig' $saved.SearchOrderConfig)
    [void](Restore-RegValue $DriverPolicyPath 'DontSearchWindowsUpdate' $saved.DontSearchWindowsUpdate)
    return $true
}

# ------------------------------
# Tweak 10: Page Combining (RAM-dependent)
# ------------------------------
function Get-PageCombiningState($Sys) {
    try {
        $m = Get-MMAgent
        $enabled = [bool]$m.PageCombining
        if ($Sys.RAMGB -ge 16) {
            if (-not $enabled) { return 'ACTIVE' } else { return 'INACTIVE' }
        } else {
            if ($enabled) { return 'ACTIVE' } else { return 'INACTIVE' }
        }
    } catch { return 'UNKNOWN' }
}
function Enable-PageCombiningTweak($Sys) {
    $m = Get-MMAgent
    Save-OriginalOnce 'PageCombining' ([pscustomobject]@{ PageCombining=[bool]$m.PageCombining })
    if ($Sys.RAMGB -ge 16) {
        Disable-MMAgent -PageCombining
    } else {
        Enable-MMAgent -PageCombining
    }
    $script:RestartRequired = $true
    return $true
}
function Restore-PageCombiningTweak {
    $saved = Get-SavedOriginal 'PageCombining'
    if ($null -eq $saved) { return $false }
    if ([bool]$saved.PageCombining) { Enable-MMAgent -PageCombining } else { Disable-MMAgent -PageCombining }
    $script:RestartRequired = $true
    return $true
}

# ------------------------------
# Display-adapter registry helpers for NVIDIA/AMD
# ------------------------------
$DisplayClassPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}'
function Get-DisplayAdapterRegistryKeys([ValidateSet('NVIDIA','AMD')][string]$Vendor) {
    if (-not (Test-Path $DisplayClassPath)) { return @() }
    $keys = @(Get-ChildItem $DisplayClassPath -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match '^\d{4}$' })
    return @($keys | Where-Object {
        $desc = ''
        $provider = ''
        try { $desc = [string](Get-ItemPropertyValue -Path $_.PSPath -Name 'DriverDesc' -ErrorAction SilentlyContinue) } catch {}
        try { $provider = [string](Get-ItemPropertyValue -Path $_.PSPath -Name 'ProviderName' -ErrorAction SilentlyContinue) } catch {}
        $text = "$desc $provider"
        if ($Vendor -eq 'NVIDIA') { $text -match 'NVIDIA' } else { $text -match 'AMD|Advanced Micro Devices|Radeon' }
    })
}

# ------------------------------
# Tweak 11: NVIDIA PreferSystemMemoryContiguous
# ------------------------------
function Get-NvidiaContiguousState($Sys) {
    if (-not $Sys.HasNvidia) { return 'N/A' }
    $keys = @(Get-DisplayAdapterRegistryKeys 'NVIDIA')
    if ($keys.Count -eq 0) { return 'N/A' }
    $vals = @($keys | ForEach-Object { Get-RegValueInfo $_.PSPath 'PreferSystemMemoryContiguous' })
    if (($vals | Where-Object { -not $_.ValueExists -or [int]$_.Value -ne 1 }).Count -eq 0) { return 'ACTIVE' }
    if (($vals | Where-Object { $_.ValueExists -and [int]$_.Value -eq 1 }).Count -eq 0) { return 'INACTIVE' }
    return 'MIXED'
}
function Enable-NvidiaContiguousTweak($Sys) {
    if (-not $Sys.HasNvidia) { throw 'No NVIDIA GPU detected.' }
    $keys = @(Get-DisplayAdapterRegistryKeys 'NVIDIA')
    if ($keys.Count -eq 0) { throw 'No NVIDIA display-class registry entry found.' }
    $orig = @()
    foreach ($k in $keys) {
        $orig += [pscustomobject]@{ Path=$k.PSPath; ValueInfo=(Get-RegValueInfo $k.PSPath 'PreferSystemMemoryContiguous') }
    }
    Save-OriginalOnce 'NvidiaContiguousMemory' ([pscustomobject]@{ Entries=$orig })
    foreach ($k in $keys) { Set-RegDword $k.PSPath 'PreferSystemMemoryContiguous' 1 }
    $script:RestartRequired = $true
    return ((Get-NvidiaContiguousState $Sys) -eq 'ACTIVE')
}
function Restore-NvidiaContiguousTweak {
    $saved = Get-SavedOriginal 'NvidiaContiguousMemory'
    if ($null -eq $saved -or -not $saved.Entries) { return $false }
    foreach ($entry in @($saved.Entries)) {
        [void](Restore-RegValue ([string]$entry.Path) 'PreferSystemMemoryContiguous' $entry.ValueInfo)
    }
    $script:RestartRequired = $true
    return $true
}

# ------------------------------
# Tweak 12: AMD ULPS
# ------------------------------
function Get-AmdUlpsState($Sys) {
    if (-not $Sys.HasAMD) { return 'N/A' }
    $keys = @(Get-DisplayAdapterRegistryKeys 'AMD')
    if ($keys.Count -eq 0) { return 'N/A' }
    $all = @()
    foreach ($k in $keys) {
        $all += Get-RegValueInfo $k.PSPath 'EnableUlps'
        $all += Get-RegValueInfo $k.PSPath 'EnableUlps_NA'
    }
    $present = @($all | Where-Object { $_.ValueExists })
    if ($present.Count -eq 0) { return 'DEFAULT' }
    if (($present | Where-Object { [int]$_.Value -ne 0 }).Count -eq 0) { return 'ACTIVE' }
    return 'INACTIVE'
}
function Enable-AmdUlpsTweak($Sys) {
    if (-not $Sys.HasAMD) { throw 'No AMD GPU detected.' }
    $keys = @(Get-DisplayAdapterRegistryKeys 'AMD')
    if ($keys.Count -eq 0) { throw 'No AMD display-class registry entry found.' }
    $orig = @()
    foreach ($k in $keys) {
        $orig += [pscustomobject]@{
            Path=$k.PSPath
            EnableUlps=(Get-RegValueInfo $k.PSPath 'EnableUlps')
            EnableUlps_NA=(Get-RegValueInfo $k.PSPath 'EnableUlps_NA')
        }
    }
    Save-OriginalOnce 'AmdULPS' ([pscustomobject]@{ Entries=$orig })
    foreach ($k in $keys) {
        Set-RegDword $k.PSPath 'EnableUlps' 0
        Set-RegDword $k.PSPath 'EnableUlps_NA' 0
    }
    $script:RestartRequired = $true
    return ((Get-AmdUlpsState $Sys) -eq 'ACTIVE')
}
function Restore-AmdUlpsTweak {
    $saved = Get-SavedOriginal 'AmdULPS'
    if ($null -eq $saved -or -not $saved.Entries) { return $false }
    foreach ($entry in @($saved.Entries)) {
        [void](Restore-RegValue ([string]$entry.Path) 'EnableUlps' $entry.EnableUlps)
        [void](Restore-RegValue ([string]$entry.Path) 'EnableUlps_NA' $entry.EnableUlps_NA)
    }
    $script:RestartRequired = $true
    return $true
}

# ------------------------------
# Tweak 13: Disable CEIP
# ------------------------------
$CeipPath = 'HKLM:\SOFTWARE\Policies\Microsoft\SQMClient\Windows'
function Get-CEIPState {
    $v = Get-RegValueInfo $CeipPath 'CEIPEnable'
    if ($v.ValueExists -and [int]$v.Value -eq 0) { return 'ACTIVE' }
    if (-not $v.ValueExists) { return 'DEFAULT' }
    return 'INACTIVE'
}
function Enable-CEIPTweak {
    $orig = Get-RegValueInfo $CeipPath 'CEIPEnable'
    Save-OriginalOnce 'CEIP' $orig
    Set-RegDword $CeipPath 'CEIPEnable' 0
    return ((Get-CEIPState) -eq 'ACTIVE')
}
function Restore-CEIPTweak {
    $saved = Get-SavedOriginal 'CEIP'
    if ($null -eq $saved) { return $false }
    return (Restore-RegValue $CeipPath 'CEIPEnable' $saved)
}

# ------------------------------
# Tweak 14: Temporary files cleanup
# ------------------------------
function Get-TempCleanupState { return 'READY' }
function Invoke-TempCleanup {
    $targets = @($env:TEMP, "$env:SystemRoot\Temp") | Select-Object -Unique
    $removed = 0
    $failed = 0
    foreach ($target in $targets) {
        if (-not (Test-Path $target)) { continue }
        Get-ChildItem -LiteralPath $target -Force -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                Remove-Item -LiteralPath $_.FullName -Recurse -Force -ErrorAction Stop
                $removed++
            } catch { $failed++ }
        }
    }
    return [pscustomobject]@{ Removed=$removed; Failed=$failed }
}

# ------------------------------
# Tweak definitions and UI
# ------------------------------
function Get-TweakDefinitions($Sys) {
    return @(
        [pscustomobject]@{ Number=3;  Id='MPO'; Name='Disable MPO (Multiplane Overlay)'; Level='ADVANCED'; Hardware='All'; Restart=$true;  GetState={ Get-MPOState }; Apply={ Enable-MPOTweak }; Restore={ Restore-MPOTweak }; Info='Disables MPO using OverlayTestMode=5. Useful mainly as a display/stutter compatibility tweak.' },
        [pscustomobject]@{ Number=4;  Id='NetBIOS'; Name='Disable NetBIOS over TCP/IP'; Level='ADVANCED'; Hardware='Network'; Restart=$false; GetState={ Get-NetBIOSState }; Apply={ Enable-NetBIOSTweak }; Restore={ Restore-NetBIOSTweak }; Info='Disables NetBIOS over TCP/IP on currently IP-enabled network adapters. Can affect legacy Windows/network discovery scenarios.' },
        [pscustomobject]@{ Number=5;  Id='NetworkHeuristics'; Name='Disable Network Heuristics'; Level='RECOMMENDED'; Hardware='All'; Restart=$false; GetState={ Get-NetworkHeuristicsState }; Apply={ Enable-NetworkHeuristicsTweak }; Restore={ Restore-NetworkHeuristicsTweak }; Info='Runs netsh int tcp set heuristics disabled. Restore uses the Windows default setting.' },
        [pscustomobject]@{ Number=6;  Id='KernelDebugPollInterval'; Name='Kernel Debug Poll Interval = 1000'; Level='EXPERIMENTAL'; Hardware='All'; Restart=$true; GetState={ Get-KernelDebugPollState }; Apply={ Enable-KernelDebugPollTweak }; Restore={ Restore-KernelDebugPollTweak }; Info='Experimental user-supplied kernel registry tweak. Performance benefit is not established; test only if you understand the tradeoff.' },
        [pscustomobject]@{ Number=7;  Id='DisableActiveProbing'; Name='Disable NCSI Active Probing'; Level='ADVANCED'; Hardware='All'; Restart=$false; GetState={ Get-ActiveProbingState }; Apply={ Enable-ActiveProbingTweak }; Restore={ Restore-ActiveProbingTweak }; Info='Disables Windows NCSI active internet probes. Microsoft warns this can make Windows/apps mis-detect internet connectivity.' },
        [pscustomobject]@{ Number=8;  Id='DisableGPUPreemption'; Name='Disable GPU Preemption'; Level='EXPERIMENTAL'; Hardware='GPU'; Restart=$true; GetState={ Get-GPUPreemptionState }; Apply={ Enable-GPUPreemptionTweak }; Restore={ Restore-GPUPreemptionTweak }; Info='Experimental user-supplied DisablePreemption registry value. Not included in automatic Recommended mode.' },
        [pscustomobject]@{ Number=9;  Id='DriverSearching'; Name='Disable Automatic Driver Searching'; Level='RECOMMENDED'; Hardware='All'; Restart=$false; GetState={ Get-DriverSearchState }; Apply={ Enable-DriverSearchTweak }; Restore={ Restore-DriverSearchTweak }; Info='Disables automatic Windows Update driver searching using the requested legacy value plus the current policy key.' },
        [pscustomobject]@{ Number=10; Id='PageCombining'; Name='Page Combining (RAM Dependent)'; Level='RECOMMENDED'; Hardware=("{0} GB RAM" -f $Sys.RAMGB); Restart=$true; GetState={ Get-PageCombiningState $Sys }; Apply={ Enable-PageCombiningTweak $Sys }; Restore={ Restore-PageCombiningTweak }; Info=(if ($Sys.RAMGB -ge 16) {'Detected 16 GB+ RAM: recommended state in this V1 profile is Page Combining disabled.'} else {'Detected less than 16 GB RAM: recommended state in this V1 profile is Page Combining enabled.'}) },
        [pscustomobject]@{ Number=11; Id='NvidiaContiguousMemory'; Name='NVIDIA Contiguous GPU Memory Allocation'; Level='ADVANCED'; Hardware='NVIDIA ONLY'; Restart=$true; GetState={ Get-NvidiaContiguousState $Sys }; Apply={ Enable-NvidiaContiguousTweak $Sys }; Restore={ Restore-NvidiaContiguousTweak }; Info='Sets PreferSystemMemoryContiguous=1 only on registry entries identified as NVIDIA display adapters.' },
        [pscustomobject]@{ Number=12; Id='AmdULPS'; Name='Disable ULPS'; Level='HARDWARE-SPECIFIC'; Hardware='AMD ONLY'; Restart=$true; GetState={ Get-AmdUlpsState $Sys }; Apply={ Enable-AmdUlpsTweak $Sys }; Restore={ Restore-AmdUlpsTweak }; Info='Sets EnableUlps and EnableUlps_NA to 0 only on registry entries identified as AMD/Radeon display adapters.' },
        [pscustomobject]@{ Number=13; Id='CEIP'; Name='Disable Windows CEIP'; Level='RECOMMENDED'; Hardware='All'; Restart=$false; GetState={ Get-CEIPState }; Apply={ Enable-CEIPTweak }; Restore={ Restore-CEIPTweak }; Info='Disables Windows Customer Experience Improvement Program through the policy registry path.' },
        [pscustomobject]@{ Number=14; Id='TempCleanup'; Name='Clean Temporary Files'; Level='RECOMMENDED'; Hardware='All'; Restart=$false; GetState={ Get-TempCleanupState }; Apply={ Invoke-TempCleanup }; Restore={$false}; Info='Removes deletable items from the current user TEMP and Windows TEMP folders. In-use files are skipped.' }
    )
}

function Get-ChangedByTool([string]$Id) {
    if ($Id -eq 'TempCleanup') { return 'N/A' }
    return $(if ($null -ne (Get-SavedOriginal $Id)) {'YES'} else {'NO'})
}

function Show-TweakList($Tweaks) {
    Write-Section 'AVAILABLE TWEAKS (3-14)'
    foreach ($t in $Tweaks) {
        $state = & $t.GetState
        $color = switch ($t.Level) {
            'RECOMMENDED' { 'Green' }
            'ADVANCED' { 'Yellow' }
            'EXPERIMENTAL' { 'Red' }
            default { 'Cyan' }
        }
        Write-Host ("[{0,2}] {1}" -f $t.Number, $t.Name) -ForegroundColor White
        Write-Host ("     Level: {0} | Hardware: {1} | Status: {2} | Changed by tool: {3}" -f $t.Level, $t.Hardware, (Format-State $state), (Get-ChangedByTool $t.Id)) -ForegroundColor $color
    }
}

function Show-TweakDetail($Tweak) {
    Write-Host ''
    Write-Host ("{0}. {1}" -f $Tweak.Number, $Tweak.Name) -ForegroundColor Cyan
    Write-Host ('-' * 68) -ForegroundColor DarkGray
    $state = & $Tweak.GetState
    Write-Host ("Level            : {0}" -f $Tweak.Level)
    Write-Host ("Hardware         : {0}" -f $Tweak.Hardware)
    Write-Host ("Current Status   : {0}" -f (Format-State $state))
    Write-Host ("Changed by Tool  : {0}" -f (Get-ChangedByTool $Tweak.Id))
    Write-Host ("Restart Required : {0}" -f $(if ($Tweak.Restart) {'YES (if changed)'} else {'NO'}))
    Write-Host ("Info             : {0}" -f $Tweak.Info) -ForegroundColor DarkGray
    return $state
}

function Invoke-TweakAction($Tweak, [ValidateSet('APPLY','RESTORE')][string]$Action) {
    try {
        if ($Tweak.Id -eq 'TempCleanup') {
            if ($Action -eq 'RESTORE') {
                Write-Host '[SKIP] Cleanup cannot restore deleted temporary files.' -ForegroundColor Yellow
                Add-Result $Tweak.Name 'SKIP' 'Temporary-file cleanup is not reversible.'
                return
            }
            $r = & $Tweak.Apply
            Write-Host ("[PASS] Cleanup complete. Removed items: {0}; in-use/failed items: {1}." -f $r.Removed, $r.Failed) -ForegroundColor Green
            Add-Result $Tweak.Name 'PASS' ("Removed {0}; skipped/failed {1}" -f $r.Removed, $r.Failed)
            return
        }

        if ($Action -eq 'APPLY') {
            $result = & $Tweak.Apply
            if ($result) {
                Write-Host '[PASS] Tweak applied.' -ForegroundColor Green
                Add-Result $Tweak.Name 'PASS' 'Applied.'
            } else {
                throw 'Verification did not confirm the requested state.'
            }
        } else {
            $result = & $Tweak.Restore
            if ($result) {
                Write-Host '[PASS] Original/default state restored.' -ForegroundColor Green
                Add-Result $Tweak.Name 'PASS' 'Restored.'
            } else {
                Write-Host '[SKIP] No saved original state is available for this tweak.' -ForegroundColor Yellow
                Add-Result $Tweak.Name 'SKIP' 'No saved original state available.'
            }
        }
    } catch {
        Write-Host ("[FAIL] {0}" -f $_.Exception.Message) -ForegroundColor Red
        Add-Result $Tweak.Name 'FAIL' $_.Exception.Message
    }
}

function Invoke-GuidedMode($Tweaks) {
    foreach ($t in $Tweaks) {
        Write-Title
        Write-Host 'GUIDED MODE - tweak by tweak' -ForegroundColor Yellow
        $state = Show-TweakDetail $t
        if ($state -eq 'N/A') {
            Write-Host '[SKIP] This tweak does not apply to the detected hardware.' -ForegroundColor Yellow
            Add-Result $t.Name 'SKIP' 'Not applicable to detected hardware.'
            Start-Sleep -Milliseconds 700
            continue
        }

        Write-Host ''
        Write-Host '[1] Apply / Turn ON tweak'
        Write-Host '[2] Restore original state / Turn OFF tweak'
        Write-Host '[3] Skip'
        Write-Host '[4] Show information again'
        Write-Host '[Q] Quit Guided Mode'

        while ($true) {
            $choice = (Read-Host 'Choose').Trim().ToUpperInvariant()
            switch ($choice) {
                '1' { Invoke-TweakAction $t 'APPLY'; break }
                '2' { Invoke-TweakAction $t 'RESTORE'; break }
                '3' { Add-Result $t.Name 'SKIP' 'User skipped.'; break }
                '4' { [void](Show-TweakDetail $t); continue }
                'Q' { return }
                default { Write-Host 'Invalid choice.' -ForegroundColor Yellow; continue }
            }
            break
        }
        Write-Host ''
        Read-Host 'Press Enter for the next tweak'
    }
}

function Invoke-RecommendedMode($Tweaks) {
    Write-Title
    Write-Host 'RECOMMENDED MODE' -ForegroundColor Green
    Write-Host 'This applies only tweaks currently classified as RECOMMENDED.' -ForegroundColor DarkGray
    $answer = (Read-Host 'Continue? [Y/N]').Trim().ToUpperInvariant()
    if ($answer -ne 'Y') { return }

    foreach ($t in @($Tweaks | Where-Object { $_.Level -eq 'RECOMMENDED' })) {
        $state = & $t.GetState
        if ($state -eq 'N/A') { Add-Result $t.Name 'SKIP' 'Not applicable.'; continue }
        Invoke-TweakAction $t 'APPLY'
    }
}

function Invoke-CustomManager($Tweaks) {
    while ($true) {
        Write-Title
        Show-TweakList $Tweaks
        Write-Host ''
        Write-Host '[B] Back'
        $inputValue = (Read-Host 'Enter tweak number').Trim().ToUpperInvariant()
        if ($inputValue -eq 'B') { return }
        $num = 0
        if (-not [int]::TryParse($inputValue, [ref]$num)) { continue }
        $t = $Tweaks | Where-Object { $_.Number -eq $num } | Select-Object -First 1
        if (-not $t) { continue }

        Write-Title
        $state = Show-TweakDetail $t
        if ($state -eq 'N/A') {
            Write-Host 'This tweak is not applicable to this PC.' -ForegroundColor Yellow
            Read-Host 'Press Enter'
            continue
        }
        Write-Host ''
        Write-Host '[1] Apply / Turn ON'
        Write-Host '[2] Restore original / Turn OFF'
        Write-Host '[B] Back'
        $c = (Read-Host 'Choose').Trim().ToUpperInvariant()
        if ($c -eq '1') { Invoke-TweakAction $t 'APPLY' }
        elseif ($c -eq '2') { Invoke-TweakAction $t 'RESTORE' }
        Read-Host 'Press Enter'
    }
}

function Invoke-RestoreManager($Tweaks) {
    Write-Title
    Write-Host 'RESTORE / UNDO CHANGES' -ForegroundColor Yellow
    Write-Host 'Only settings with a saved original state from this tool will be restored.' -ForegroundColor DarkGray
    Write-Host ''
    Write-Host '[1] Restore ALL tweaks changed by this tool'
    Write-Host '[2] Choose one tweak to restore'
    Write-Host '[B] Back'
    $choice = (Read-Host 'Choose').Trim().ToUpperInvariant()
    if ($choice -eq 'B') { return }
    if ($choice -eq '1') {
        foreach ($t in $Tweaks) {
            if ($t.Id -eq 'TempCleanup') { continue }
            if ($null -ne (Get-SavedOriginal $t.Id)) { Invoke-TweakAction $t 'RESTORE' }
        }
    } elseif ($choice -eq '2') {
        Show-TweakList $Tweaks
        $n = 0
        $raw = Read-Host 'Tweak number'
        if ([int]::TryParse($raw, [ref]$n)) {
            $t = $Tweaks | Where-Object { $_.Number -eq $n } | Select-Object -First 1
            if ($t) { Invoke-TweakAction $t 'RESTORE' }
        }
    }
    Read-Host 'Press Enter'
}

function Show-ResultsSummary {
    Write-Title
    Write-Section '15. SUCCESS / FAILURE / SKIP REPORT'
    if ($script:Results.Count -eq 0) {
        Write-Host 'No changes/actions were performed in this session.' -ForegroundColor DarkGray
    } else {
        foreach ($r in $script:Results) {
            $color = switch ($r.Status) { 'PASS' {'Green'} 'FAIL' {'Red'} 'SKIP' {'Yellow'} default {'Gray'} }
            Write-Host ("[{0}] {1} - {2}" -f $r.Status, $r.Tweak, $r.Message) -ForegroundColor $color
        }
        Write-Host ''
        Write-Host ("Succeeded : {0}" -f @($script:Results | Where-Object Status -eq 'PASS').Count)
        Write-Host ("Skipped   : {0}" -f @($script:Results | Where-Object Status -eq 'SKIP').Count)
        Write-Host ("Failed    : {0}" -f @($script:Results | Where-Object Status -eq 'FAIL').Count)
    }

    Write-Section '16. RESTART STATUS'
    if ($script:RestartRequired) {
        Write-Host 'Restart required: YES' -ForegroundColor Yellow
        $answer = (Read-Host 'Restart Windows now? [Y/N]').Trim().ToUpperInvariant()
        if ($answer -eq 'Y') {
            Write-Log 'INFO | Restart requested by user.'
            Restart-Computer
        } else {
            Write-Host 'Restart postponed. Changes that require restart may not be active yet.' -ForegroundColor Yellow
        }
    } else {
        Write-Host 'Restart required: NO' -ForegroundColor Green
    }
    Write-Host ''
    Write-Host ("Log: {0}" -f $LogFile) -ForegroundColor DarkGray
    Write-Host ("Original-state backup: {0}" -f $BackupFile) -ForegroundColor DarkGray
}

# ------------------------------
# Main
# ------------------------------
Ensure-Administrator
Ensure-DataDirectory
Write-Log "START | $ToolName v$ToolVersion"

$sys = Get-SystemInfo
$Tweaks = Get-TweakDefinitions $sys

Write-Title
Show-SystemInfo $sys
Write-Section 'CORE SYSTEM FUNCTIONS'
Write-Host '[1] Create restore point before changes'
Write-Host '[2] Detect Windows version / hardware'
Write-Host '[15] Success / failure / skip reporting'
Write-Host '[16] Restart only if needed'
Write-Host ''
Write-Host 'System detection completed.' -ForegroundColor Green

# Per user requirement, attempt a restore point at the beginning before any tweak changes.
$continue = Create-SafetyRestorePoint
if (-not $continue) {
    Write-Host 'No tweaks were changed.' -ForegroundColor Yellow
    Write-Log 'STOP | User declined to continue after restore-point failure.'
    Read-Host 'Press Enter to exit'
    exit
}

while ($true) {
    Write-Title
    Show-SystemInfo $sys
    Show-TweakList $Tweaks
    Write-Host ''
    Write-Host '[G] Guided Mode - go through every tweak one by one' -ForegroundColor Cyan
    Write-Host '[R] Apply Recommended tweaks only' -ForegroundColor Green
    Write-Host '[C] Custom Manager - choose any tweak' -ForegroundColor White
    Write-Host '[U] Undo / Restore changes' -ForegroundColor Yellow
    Write-Host '[L] View activity log' -ForegroundColor Gray
    Write-Host '[Q] Finish / Exit' -ForegroundColor White

    $choice = (Read-Host 'Choose').Trim().ToUpperInvariant()
    switch ($choice) {
        'G' { Invoke-GuidedMode $Tweaks }
        'R' { Invoke-RecommendedMode $Tweaks }
        'C' { Invoke-CustomManager $Tweaks }
        'U' { Invoke-RestoreManager $Tweaks }
        'L' {
            Write-Title
            Write-Section 'ACTIVITY LOG'
            if (Test-Path $LogFile) { Get-Content $LogFile | Select-Object -Last 80 | ForEach-Object { Write-Host $_ } }
            else { Write-Host 'No log exists yet.' }
            Read-Host 'Press Enter'
        }
        'Q' { break }
        default { continue }
    }
    if ($choice -eq 'Q') { break }
}

Show-ResultsSummary
Write-Log "END | $ToolName v$ToolVersion"
Write-Host ''
Read-Host 'Press Enter to close'
